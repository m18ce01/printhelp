1、解压本工具到本地目录
2、双击 PrintFormatHelper/tool/run.bat 运行